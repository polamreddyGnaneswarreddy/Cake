INGREDIENTS (For the Chocolate Mousse recipe)

1. 3 eggs (~55g/2 oz each)
2. 125g / 4.5 oz dark chocolate , bittersweet / 70% cocoa (Note 1)
3. 10g / 0.3 oz unsalted butter
4. 1/2 cup cream , full fat (Note 2)
5. 3 tbsp caster sugar (superfine white sugar)
DECORATIONS:
6. More whipped cream
7. Chocolate shavings (Note 3)