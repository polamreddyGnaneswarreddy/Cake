RECIPE

1. Separate eggs and yolks while eggs are cold. Place whites in a large bowl and yolks in a small bowl. Leave whites while you prepare other ingredients. (Note 4)
2. Yolks: Whisk yolks.
3. Melt chocolate & butter: Place chocolate and butter in a bowl. Melt in the microwave in 30 second bursts, stirring in between, until smooth. (Stir in optional flavourings at this point, but read Note 6 first). Set aside to cool - proceed with other steps.
4. Whip cream: Beat cream until stiff peaks form (see video).
5. Whip whites: Add sugar. Beat whites until firm peaks form (see video, Note 5)
6. FOLDING:
7. Fold egg yolks into cream using a rubber spatula - 8 folds max. Streaks is ok.
8. Check Chocolate Temp: Touch the chocolate. Should still be runny but only lukewarm. If too thick, microwave 2 x 3 seconds until runny.
9. Pour chocolate into cream yolk mixture. Fold through - 8 folds max. Streaks ok.
10. Add 1/4 of beaten egg whites into chocolate mixture. Fold through until incorporated - "smear" the spatular across surface to blend white lumps in - aim for 10 folds. 
11. Pour chocolate mixture into egg whites. Fold through until incorporated and no more white lumps remain - aim for 12 folds max.
12. Divide mixture between 4 small glasses or pots. Refrigerate for at least 5 hours, preferably overnight.
13. To serve, garnish with cream and chocolate shavings. Raspberries and a tiny sprig of mint for colour would also be lovely!